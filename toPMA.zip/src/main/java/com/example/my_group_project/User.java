package com.example.my_group_project ;

public class User extends Person {
}
